# Sparse Capacitance Rule Completion: Support Protocols, Model Complexity, and Extraction Fidelity

## Abstract

Completing a capacitance rule library from sparse target-process observations is distinct from applying an extractor to a routed layout. We compare numerical completion, frozen support-conditioned predictors and target adaptation under common observation budgets, and export completed rules into an unchanged extraction and timing flow. Target adaptation and simple gates remain competitive alternatives to full numerical-neural fusion. In a matched FEM continuation, low-support training benefits binary gating more strongly; full fusion retains a small advantage under the prespecified four-budget average, while binary is more accurate at the smallest budget. Improvements at small budgets coexist with degradation at larger budgets and under the original support protocol. Fixed-layout extraction shows substantial gains over interpolation but mixed increments over binary gating, including timing-tail regressions. The evidence establishes budget- and protocol-dependent rankings in the evaluated cohorts, rather than general characterization savings or signoff accuracy.

## Introduction and research questions

An existing geometry-to-capacitance rule library can support offline completion without replacing the parasitic extractor. The engineering decision involves the observation budget, source training, target fitting and completion computation, followed by error propagation through a fixed downstream flow. We organize the evidence around three questions.

**RQ1:** How do numerical completion, frozen conditional prediction and target adaptation compare at the same target observation budget? **RQ2:** How does the training support protocol interact with model complexity and change these rankings? **RQ3:** How do completed-rule errors propagate to net capacitance and static timing in a fixed extraction flow?

The concrete contributions are an information-budget protocol with sealed queries and separate cost stages; a matched continuation showing budget-dependent support-protocol and complexity tradeoffs; and a native rule-export interface with paired extraction/timing error evidence. These are testable artifacts and empirical observations, not a claim that changing the paper's positioning establishes algorithmic novelty.

## Related work

AttentionCap learns capacitance matrices from conductor geometry using a Transformer and a Laplacian head [1]. We reuse the official implementation on the common reconstructible FEM geometry, adapting its input representation for material layers and the external ground boundary. Supervision is restricted to the same three components available to all methods. This is an adapted baseline, not a reproduction of the authors' original dataset or reported error. Flash-CNNCap maps three-dimensional windows to contribution images and reconstructs capacitance matrices/netlists [2]. Its window and DEF-to-SPEF task differs from fixed-grid rule completion; we neither convert LUT sequences to artificial images nor claim numerical superiority over its complete extractor.

Tsai et al. encode geometry and layer thickness for interconnect exploration and demonstrate unseen-thickness prediction without repeated per-thickness retraining [3]. Our direct MLP is a paper-inspired implementation using the available coordinates and structural/material summaries, with finite learning-rate selection and equal-support target adaptation. It does not reproduce their full pattern extraction or layout assembly. Within-stack thickness generalization is distinct from cross-stack adaptation.

ResCap already combines a physical estimate and a learned residual [4]. Accuracy-Based Hybrid PEX selects among rule, neural and field-solver methods according to accuracy needs [5]. CNP/ANP establish conditioning on observed context sets [6,7], and AIL-DNN addresses adaptive incremental learning [8]. We do not claim first use of residual learning, hybridization, observation conditioning or adaptive sampling. Our empirical distinction is the frozen information budget and native rule-library fidelity evaluation. All reported comparisons use our matched physical definitions and NRMSE; numbers from unrelated papers are not assembled into a cross-paper ranking.

## Rule-completion interface and models

For a table with candidate geometries X and permitted context c, let S be purchased indices and y(S) their capacitance vectors. A predictor computes F(X,c,S,y(S)) on the entire fixed grid. The evaluator seals Q, disjoint from the candidate pool from which S can be selected. Q is unchanged across budgets, methods and sampling trajectories for a table/data seed. Unqueried candidate labels are also hidden. Source-trained normalization is fixed. Candidate and query geometry are permitted transductive inputs; invariance to a changed query set or online single-query deployment is not assumed.

A budget unit is one unique geometric reference query, including initialization. One geometry may return several components and require multiple conductor excitations; those components do not multiply the query charge. We report the excitation work separately. Repeated queries use a declared cache and cannot reveal a label before being charged. Public-rule accesses simulate observations of existing source-rule values. FEM labels derive from a two-dimensional material-stack cross section with infinite extrusion, not a general three-dimensional window.

Public outputs are coupling and ground capacitance in source-rule-native per-length units. Their 1,713 tables all have rank-one geometry variation. FEM outputs, in F/m, are summed two-sided lateral coupling, ground including both the external boundary and explicit grounded context, and diagonal coupling. Independent width and spacing parameters make the FEM grid rank two; parameter dimension and field dimension are different concepts.

The exporter substitutes only unobserved capacitance tokens on eligible held-out rows and preserves observed rows, comments, other rule rows and resistance. Of the original 84 downstream holdouts, one has insufficient points for the shared sealed-Q protocol and remains golden; 83 are eligible. All methods use this identical subset. The resulting rule file is consumed by native OpenRCX on the same routed/connected database, SDC, cell libraries and executable. Reference timing comes from the full original rule file. Other rule tables retain their already available golden values for every method. Thus the native budget applies to these selected held-out tables, not to rebuilding an entire PDK from scratch; public fitting also contains other tables from the same processes.

The support anchor is computed from S and y(S). A shared Transformer encodes geometry, structural/material context, observed values, an observation indicator and the anchor. Its residual head predicts a correction. The full model combines numerical corrections and neural raw/clamped corrections with component-wise weights, then applies nonnegativity and restores observations exactly. Classical options include PCHIP, aligned-width interpolation and six RBF-GP configurations: length multipliers 0.5/1/2 with ridge 1e-6/1e-4. The anchor is a separate control because it differs from rank-matched multilinear interpolation on sparse rank-two grids.

Full inference evaluates applicable branches before fusing them. Low gate weight does not automatically avoid branch computation. Ungated residual and binary anchor/neural controls reuse the original fitting data, warm start, architecture core, optimizer budget and three training seeds. Their actual local weights were verified and reloaded; historical fixed-mask scores were not reused as budget predictions. A linear-only dictionary mask is evaluated as a separately labeled pruning ablation. All three registered source-validation comparisons favored retaining the full dictionary under the strict error selection rule.

Other controls are explicitly implemented rank-matched multilinear interpolation, validation-selected local affine, an independently selected GP, PCHIP where applicable (anchor fallback on rank-two tables), a direct MLP, and a deterministic mean-aggregation CNP. Direct MLP target adaptation uses only the same purchased S; no early stopping or free calibration label uses Q. Zero-target MLP and AttentionCap predictions are clearly information-limited controls. The anchor-conditioned method has no defined empty-support interface and is not assigned a fabricated zero-observation result.

## Evaluation populations, metrics and costs

Effective public fitting/selection/confirmation counts are 1,051/246/340; FEM counts are 16/24/16; FreePDK15-to-ASAP7 counts are 8/12/8. All 84 downstream tables and duplicate content are absent from public fitting and selection. Confirmation cohorts have been used previously, so this is a new protocol on existing confirmation data, not a new blind test. Three published full members per setting and 18 matched-control members pass checkpoint hash and configuration checks.

The inherited numerical evidence retains 14,688 initial, 11,016 expanded-coverage and 10,368 boundary receipts. Mesh/boundary convergence, flux-energy consistency, reciprocity and matrix checks pass their recorded criteria. The analytic coaxial pilot has relative error 0.00026334. These checks support the declared numerical reference; mutual consistency alone is not an external three-dimensional or silicon signoff validation. No new field-solver experiment is claimed in this study.

Budgets are 4/8/16/32/64, filtered by candidate-pool size. Three data seeds 11/29/47 define fixed Q (20% with at least two points for ordinary tables). Four geometry-coverage points initialize each trajectory and count toward B. A common two-point rule applies to tables with four to seven nodes; tables with fewer than four are ineligible for every method. Public confirmation has 338 eligible tables at B4/B8 and none at B16 or larger. Primary comparisons share geometry-coverage S; random and curvature comparisons share Q and initialization but may select different later S.

Primary macro NRMSE pools squared error and squared truth within process/family/component, then averages the defined component ratios. Native MAE and table P95/P99 absolute errors accompany it. No weak-capacitance observations are removed. All-zero truth components remain in absolute metrics and are excluded only from undefined relative normalization. Failures and unavailable budgets remain explicit. Group bootstrap uses 2,000 paired resamples of dependency groups within process; repeated data seeds and all families of one FEM layer stay together. These are pointwise intervals, not uncertainty over a broad population of process technologies. Training-seed variation is reported separately at fixed data seed 11.

Two learning rates and a fixed 3,000-update endpoint are offered to new MLP/CNP and adapted AttentionCap controls; source validation selects the candidate, followed by training seeds 1/2. Target adaptation candidates are 0/50/200 updates, selected on source validation only. Local affine reuses the earlier validation choices 4/8/8. Independent GP selection uses the six registered configurations. The new MLP/CNP source sampler balances families and samples tables uniformly within family; it does not match the archived process-balanced sampler or its longer training schedule. Therefore only the archived full/residual/binary controls are matched in training budget. New models match source data and target observations with a finite selection opportunity, not globally optimized performance. No confirmation-driven router search or unbounded correction round is performed.

Error thresholds are the first, second and third quartiles of source-validation anchor table errors at B8 (or the largest feasible smaller budget). They are descriptive thresholds, not application-certified tolerances. We report the smallest measured budget attaining each threshold, preserving non-attainment rather than extrapolating an unmeasured budget. Costs distinguish unique geometry queries, original fine-only CPU work, original coarse+fine+wide validated CPU work, and measured completion/target-fitting/selection/export/native time. The 12,024 geometry-index entries link to original solver records and exact fine-matrix projections. Cached charged wall time is not substituted for characterization work. Historical source CPU/GPU cost is incomplete; no total-cost or real solver wall-speedup claim follows.

We distinguish **E1**, the historical process/family/component pooled query NRMSE computed after averaging predictions of the three trained members, from **M**, the mechanism metric computed separately for each member and then averaged over members. M averages nonzero-truth component NRMSE within table/data-seed/budget, then data seeds, tables within process-layer groups, groups and the four budgets equally. Pooling squared errors, averaging errors, and averaging predictions do not commute. E1 and M values are never subtracted from one another. OLD_E1_POOLED_BY_SEED reconstructs E1-style pooling for individual members; it does not turn them into an ensemble.

Source training, purchased target observations, target adaptation, rule completion and native extraction/STA are separate cost stages. Historical adaptation-plus-completion times remain combined; pure adaptation latency cannot be inferred. All findings below reuse completed records; this closeout adds no predictions or timing measurements.

## RQ1: Same-observation rule completion

All relative-error tables in this section use E1; trained predictors use their archived three-member ensemble, not the mean of three member errors. They compare the same S/Q and target observation budget, while source-training opportunities differ as specified above.

| Setting | B | cmi | anchor | affine | gp | mlp_adapt | cnp | residual | binary | full |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| public | 4 | 0.4229 | 0.4229 | 0.4266 | 0.3887 | 0.2860 | 0.2650 | 0.0776 | 0.0793 | 0.0708 |
| public | 8 | 0.3689 | 0.3689 | 0.3532 | 0.4013 | 0.2599 | 0.2374 | 0.0682 | 0.0648 | 0.0609 |
| reference | 4 | 0.2670 | 0.3391 | 0.2602 | 0.2767 | 0.0515 | 0.2356 | 0.1100 | 0.1315 | 0.1233 |
| reference | 8 | 0.2296 | 0.2752 | 0.2253 | 0.1633 | 0.0420 | 0.2313 | 0.0917 | 0.0947 | 0.0925 |
| reference | 16 | 0.1687 | 0.1525 | 0.1709 | 0.0543 | 0.0316 | 0.2297 | 0.0681 | 0.0565 | 0.0409 |
| reference | 32 | 0.1011 | 0.0942 | 0.0986 | 0.0354 | 0.0252 | 0.2274 | 0.0657 | 0.0537 | 0.0332 |
| reference | 64 | 0.0685 | 0.0444 | 0.0615 | 0.0280 | 0.0248 | 0.2271 | 0.0609 | 0.0491 | 0.0250 |
| to_asap7 | 4 | 0.2640 | 0.3358 | 0.2572 | 0.2734 | 0.0477 | 0.2138 | 0.1410 | 0.1153 | 0.1182 |
| to_asap7 | 8 | 0.2261 | 0.2698 | 0.2217 | 0.1584 | 0.0366 | 0.2126 | 0.1282 | 0.0961 | 0.1034 |
| to_asap7 | 16 | 0.1662 | 0.1500 | 0.1682 | 0.0526 | 0.0310 | 0.2135 | 0.1069 | 0.0762 | 0.0685 |
| to_asap7 | 32 | 0.1005 | 0.0897 | 0.0969 | 0.0341 | 0.0272 | 0.2127 | 0.0954 | 0.0700 | 0.0495 |
| to_asap7 | 64 | 0.0675 | 0.0435 | 0.0601 | 0.0271 | 0.0264 | 0.2136 | 0.0814 | 0.0611 | 0.0386 |


At four FEM observations, full fusion improves over the anchor but loses to the same-support adapted MLP. The difference persists through the low and middle budgets. For transfer at B64, full is 0.0386, GP is 0.0271, and adapted MLP is 0.0264. These controls prevent interpreting an interpolation comparison as evidence that complex fusion is uniquely data efficient. Full inference avoids target optimizer updates, while the MLP pays a measured fitting cost; completion_cost.pdf presents this separate tradeoff.

Public results are restricted to the feasible rank-one cohort. At B4, full/binary/anchor NRMSE is 0.0708/0.0793/0.4229; at B8 it is 0.0609/0.0648/0.3689. Higher FEM budgets cannot be presented as public-corpus evidence. The curves retain simple controls and do not assume that full fusion must be selected for deployment.

### Threshold attainment and cost stages

| Setting | Method | Error threshold | Reached trajectories | Not reached | Median B among reached |
| --- | --- | --- | --- | --- | --- |
| public | anchor | 0.1356 | 455/991 | 536 | 8.0 |
| public | affine | 0.1356 | 335/991 | 656 | 4.0 |
| public | gp | 0.1356 | 553/991 | 438 | 8.0 |
| public | mlp_adapt | 0.1356 | 734/991 | 257 | 4.0 |
| public | binary | 0.1356 | 944/991 | 47 | 4.0 |
| public | full | 0.1356 | 957/991 | 34 | 4.0 |
| reference | anchor | 0.2882 | 48/48 | 0 | 16.0 |
| reference | affine | 0.2882 | 48/48 | 0 | 8.0 |
| reference | gp | 0.2882 | 48/48 | 0 | 8.0 |
| reference | mlp_adapt | 0.2882 | 48/48 | 0 | 4.0 |
| reference | binary | 0.2882 | 48/48 | 0 | 4.0 |
| reference | full | 0.2882 | 48/48 | 0 | 4.0 |
| to_asap7 | anchor | 0.2908 | 24/24 | 0 | 16.0 |
| to_asap7 | affine | 0.2908 | 24/24 | 0 | 8.0 |
| to_asap7 | gp | 0.2908 | 24/24 | 0 | 8.0 |
| to_asap7 | mlp_adapt | 0.2908 | 24/24 | 0 | 4.0 |
| to_asap7 | binary | 0.2908 | 24/24 | 0 | 4.0 |
| to_asap7 | full | 0.2908 | 24/24 | 0 | 4.0 |


The table retains non-attainment, and its conditional median is not a common-population saving estimate. Paired minimum-budget/cost comparisons preserve both-reached, one-sided and neither-reached outcomes. A favorable comparison to an anchor does not establish a benefit over adapted MLP or binary residual completion. Public savings refer only to simulated observations. FEM CPU numbers are recorded-cost replay; source pretraining and adaptation prevent converting them into a single measured end-to-end acceleration factor.

| Setting | B | Recorded fine CPU s | Recorded validated CPU s | Full completion s | MLP adaptation+completion s |
| --- | --- | --- | --- | --- | --- |
| public | 4 | unknown | unknown | 0.0076 | 0.4295 |
| public | 8 | unknown | unknown | 0.0077 | 0.4287 |
| reference | 4 | 28.50 | 65.80 | 0.0225 | 0.4974 |
| reference | 8 | 50.55 | 117.38 | 0.0230 | 0.4908 |
| reference | 16 | 101.81 | 236.94 | 0.0239 | 0.4832 |
| reference | 32 | 190.73 | 445.96 | 0.0250 | 0.4831 |
| reference | 64 | 370.21 | 867.02 | 0.0278 | 0.4846 |
| to_asap7 | 4 | 31.89 | 74.76 | 0.0220 | 0.5039 |
| to_asap7 | 8 | 57.40 | 135.01 | 0.0228 | 0.4791 |
| to_asap7 | 16 | 114.26 | 269.62 | 0.0236 | 0.4804 |
| to_asap7 | 32 | 215.45 | 510.48 | 0.0282 | 0.4843 |
| to_asap7 | 64 | 418.24 | 991.67 | 0.0274 | 0.4792 |


Original fine/validated CPU seconds and archived completion wall seconds are different measurements. They describe the target-phase tradeoff without asserting an amortized or measured end-to-end acceleration.

### Target adaptation and related-work control

reference: at the frozen per-table threshold 0.28821552937419825, all 48 table/seed trajectories reach the threshold for both full and anchor. Their summed replayed fine-only CPU work is 1367.89 versus 3567.81 seconds. Full and adapted MLP instead require identical measured budgets in all 48 trajectories, with identical recorded characterization work. These sums count repeated experimental trajectories; they are not a unique PDK build cost.

to_asap7: at the frozen per-table threshold 0.2907519133283675, all 24 table/seed trajectories reach the threshold for both full and anchor. Their summed replayed fine-only CPU work is 765.41 versus 2005.59 seconds. Full and adapted MLP instead require identical measured budgets in all 24 trajectories, with identical recorded characterization work. These sums count repeated experimental trajectories; they are not a unique PDK build cost.

| Setting | B | Adapted AttentionCap | Adapted MLP | Full |
| --- | --- | --- | --- | --- |
| reference | 4 | 0.4546 | 0.0515 | 0.1233 |
| reference | 8 | 0.2256 | 0.0420 | 0.0925 |
| reference | 16 | 0.2025 | 0.0316 | 0.0409 |
| reference | 32 | 0.1677 | 0.0252 | 0.0332 |
| reference | 64 | 0.1657 | 0.0248 | 0.0250 |
| to_asap7 | 4 | 6.8753 | 0.0477 | 0.1182 |
| to_asap7 | 8 | 0.3199 | 0.0366 | 0.1034 |
| to_asap7 | 16 | 0.2120 | 0.0310 | 0.0685 |
| to_asap7 | 32 | 0.2153 | 0.0272 | 0.0495 |
| to_asap7 | 64 | 0.1791 | 0.0264 | 0.0386 |


The component-supervised official AttentionCap adaptation does not remove the stronger direct-MLP counterexample. Its finite training and modified heterogeneous-material/boundary representation limit conclusions about the original paper's method; no cross-paper benchmark ranking is made. The additional ASAP7-to-FreePDK15 direct-MLP experiment uses 8 fitting, 12 source-selection and 8 target-confirmation tables. Its pooled zero-target and adapted errors are 0.4414 and 0.0408, respectively. This is reverse-direction evidence for the direct baseline, not evidence that the full gate transfers bidirectionally. Two stacks still do not establish broad process generalization.

The first measured attainment budget is not the lowest necessary number of observations. Full, binary and adapted MLP all attain the frozen middle FEM/transfer thresholds at B4; no observation below B4 was tested. These are retrospective query-truth statistics, not an operational online stopping rule.

## RQ2: Support protocol and model complexity

The archived FEM models were trained on 16 tables with 153 geometry nodes each. Original missing-point protocols expose 46,77,107 or 138 nodes; whole-width holdout exposes 136. The budgets 4,8,16 and 32 are below that support-count range. We compare Full and binary under the original support protocol H and a nested low-support protocol L, with the same three starting seeds. Each member receives 2000 additional AdamW updates (learning rate 0.0002, weight decay 0.0001, gradient clipping 1), all parameters trainable, dropout 0 and equally weighted four-family normalized Huber losses. Missing historical optimizer states are reset identically in both arms. L takes a geometry-only coverage prefix of 4,8,16 or 32 points from H; the table, full geometry, original loss queries, normalization and loss weights remain paired. Removed observations are not additional loss queries. This changes both support cardinality and coverage, so the contrast identifies a support-protocol effect rather than a pure cardinality effect.

We evaluate all 12 fixed endpoints and the six starting members on the same 192 low-budget cells, plus 64 original-support cells for retention. The primary mechanism metric averages component query NRMSE within each table/data seed/budget, then data seeds, tables within process-layer groups, groups, and finally the four budgets equally. This differs from the earlier tables' process/family/component pooled SSE/SY metric. The 16 confirmation tables and four dependency groups have been used previously; this is a retrospective diagnosis. Three training seeds are paired repeats, not three independent ensembles.



The following table uses M, averaged over the three individual training-seed errors. Its last row preserves the prespecified equal weighting of B4/B8/B16/B32. It is neither an ensemble error nor an E1 pooled score.

| B | Full-0 | Full-H | Full-L | binary-L | G |
| --- | --- | --- | --- | --- | --- |
| 4 | 0.121116 | 0.121262 | 0.095980 | 0.088087 | -0.007893 |
| 8 | 0.091967 | 0.090467 | 0.082070 | 0.077841 | -0.004229 |
| 16 | 0.040200 | 0.041455 | 0.048232 | 0.056488 | 0.008256 |
| 32 | 0.030848 | 0.033126 | 0.039764 | 0.055388 | 0.015624 |
| Equal-budget mean | 0.071033 | 0.071577 | 0.066512 | 0.069451 | 0.002939 |


![M across budgets, from the same archived member results; original Full remains an explicit reference.](figures/mechanism_budget.pdf)

Full-L has 4.23% lower four-budget mean NRMSE than binary-L, with positive G in all three seeds. This is a relative change of these mean NRMSE values, not MAPE or a 4.23% reduction of every capacitance error. The original Full-0/binary-0 gap is 0.014088; after L it is 0.002939, a 79.1% narrowing. Low-support continuation did not create Full's average advantage.

At B4, binary-L is more accurate in all three seeds. At B8 it is better in two seeds and slightly worse in one, while its mean is lower. At B16/B32, Full-L outperforms binary-L but is worse than both Full-0 and Full-H: increases relative to Full-0 are 19.98%/28.90%, and relative to Full-H 16.35%/20.04%. These rank changes do not validate a post-hoc deployment policy choosing binary-L at small B and old Full at large B; no independent policy-selection evidence exists.

Define C[a]=E[a,0]-E[a,H], D[a]=E[a,H]-E[a,L], I=D[Full]-D[binary] and G=E[binary,L]-E[Full,L], all in M units. The paired seed effects are:

| train_seed | C_Full | C_binary | D_Full | D_binary | I | G |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | 0.007591 | -0.000351 | -0.005250 | 0.012898 | -0.018149 | 0.002811 |
| 1 | -0.006932 | -0.001340 | 0.009471 | 0.019413 | -0.009942 | 0.000597 |
| 2 | -0.002293 | 0.001402 | 0.010977 | 0.014988 | -0.004011 | 0.005410 |


Mean D[Full]=0.005066 is positive in two seeds, D[binary]=0.015766 in all three; I=-0.010701 is negative in all three. Binary thus responds more strongly. G=0.002939 is positive in all three, with a conditional group-bootstrap interval [0.000372,0.005507]. Four existing dependency groups and three fixed training seeds do not support population-wide process guarantees. This is a retrospective diagnosis; the confirmation cohort was already used to identify the question. Nested thinning changes both support count and coverage, not cardinality alone.

### Retention and computation

The same group/table weighting applied to 64 original-protocol units yields the following member means. Low-support training is not a uniform improvement over H or over the starting models.

| Model | 0 | H | L |
| --- | --- | --- | --- |
| Full | 0.043586 | 0.046481 | 0.052092 |
| binary | 0.063662 | 0.057409 | 0.068084 |


The next table reports archived shared-encoding CPU plus one member forward, in milliseconds. It is an estimated single-member completion cost, not measured ensemble wall latency and not OpenRCX/STA runtime.

| B | Full-L ms | binary-L ms | Full/binary |
| --- | --- | --- | --- |
| 4 | 15.05 | 8.58 | 1.75 |
| 8 | 16.22 | 9.50 | 1.71 |
| 16 | 16.75 | 10.75 | 1.56 |
| 32 | 18.01 | 10.47 | 1.72 |


Full-L costs 1.56–1.75 times binary-L here. Actual evaluation reused encoding across nine versions per architecture/cell; multiplying that shared cost by all versions would overcount measured work. Three-member computation would be shared encoding plus three forwards, not these single-member numbers. L source continuation costs 515.45 CPU seconds for Full and 311.79 for binary across their three seeds; these are incremental costs, not full training lifecycle totals. B4/B8 mean error and computation both favor binary-L, whereas B16/B32 compare a more accurate, more expensive Full-L against binary-L; old Full remains a better error reference at those larger budgets. No same-factor characterization or extraction speedup follows.

In 1728 paired cell/component/seed P99 absolute capacitance-error comparisons, Full-L is lower in 887, exactly tied in 225 and higher in 616. These correlated comparisons are not independent designs, globally pooled P99, or STA slack. All signed differences and original-support tails remain available in the referenced archives. Historical MLP/CNP recomputed under M are descriptive only: training opportunities, target adaptation and model aggregation differ from this matched experiment.

## RQ3: Native extraction and STA error propagation

The native study uses eight fixed layouts, B4/B8 and three data seeds, with 83 eligible held-out rule tables replaced and all other rules kept complete. The original 84-table set excludes one two-node ASAP7 OVER table under the common n<4 feasibility rule for every method; it remains golden. Golden means extraction using the full rules with the same ODB, SDC, Liberty and tool configuration. All 240 candidate native runs and eight golden replays completed; net C/R golden replay agrees and candidate R is unchanged. These are archived original models, not the H/L continuation endpoints.

For compactness, the table first averages the three data seeds within each layout/budget, then equally averages eight layouts per budget. WS is the absolute deviation of worst slack from the golden reference. P99 is the 99th percentile of absolute endpoint slack errors within each run, subsequently averaged; it is not a pooled endpoint percentile. Timing errors are converted from ns to ps. Individual layout values and all other metrics are in native_all_layouts_all_metrics.csv.

| B | Method | Net C NRMSE | WS abs error ps | Mean per-layout P99 error ps |
| --- | --- | --- | --- | --- |
| 4 | binary | 0.002309 | 1.198927 | 2.009238 |
| 4 | cmi | 0.025679 | 29.009281 | 41.659926 |
| 4 | full | 0.003297 | 2.614599 | 4.254610 |
| 8 | binary | 0.002306 | 2.339536 | 3.442434 |
| 8 | cmi | 0.016797 | 19.390275 | 26.876283 |
| 8 | full | 0.002411 | 2.859654 | 4.066398 |


Across the 16 layout/budget conditions (each a three-data-seed mean), Full improves net-C NRMSE and absolute WS error over CMI in 16/16 conditions. Relative to binary, net-C improves/ties/worsens in 6/0/10, WS in 4/0/12, and P99 slack error in 6/0/10. The largest P99 degradation is 7.643287 ps at GF180/ibex B4: Full's P99 absolute error minus binary's, averaged over the same seeds. It is an error increase relative to the golden reference, not a loss of actual chip slack.

Tails and decisions do not all improve with net-C error. Against binary, TNS absolute error improves/ties/worsens in 5/4/7, false negatives tie in 16/16, and false positives tie/worsen in 14/2. Against CMI, TNS counts are 13/3/0, while false positives improve/tie/worsen in 4/9/3. native_delta_summary.csv retains all 19 reviewed metrics for both comparisons, including path/endpoint overlap and ranking. Numerical ties follow the existing tolerance max(1e-12,1e-9 times the larger magnitude); it is not an engineering-equivalence threshold. Shared libraries and layouts make the 16 conditions dependent, not 16 independent technologies.

## Limitations and conclusion

Public geometry is rank one; FEM is idealized two-dimensional electrostatics. Native evaluation replaces selected held-out rules, not an entirely sparse-characterized PDK. Physical accuracy, unseen processes, whole-process cost, true solver wall savings and signoff correctness are not established. The two-stack transfer and adapted AttentionCap results are unchanged; this mechanism study neither repairs their failure boundaries nor measures new downstream behavior. No endpoint-selection or budget-dependent router is validated by these retrospective rankings.

The evaluated rule-completion interface improves extraction fidelity in several fixed-observation settings, while target adaptation and simple residual gates remain competitive alternatives. In matched FEM continuation, low-support training benefits binary gating more than full numerical-neural fusion. Full retains a small advantage under the prespecified four-budget average, whereas binary is more accurate at the smallest budget. Low-support training also degrades larger-support conditions. These observations establish protocol- and budget-dependent rankings within this cohort, not universal architectural superiority or whole-process characterization savings.

## Artifact availability

The research branch contains evaluation scripts, CSVs, source manifests and editable manuscripts. Large checkpoint and dataset references include local paths and hashes; a hash or a successful local run does not establish publicly downloadable weights or a complete external reproduction environment. We make no claim that all underlying artifacts are openly available. This paper's small derived tables, figure and renderer are packaged; the historical archives are referenced rather than duplicated. No new data or weight publication is performed.

## References

[1] Huang et al. AttentionCap: Transformer Based Capacitance Matrix Learning Toward Full-Chip Extraction. DAC 2026 / arXiv:2606.08161. https://github.com/THU-numbda/AttentionCap

[2] Flash-CNNCap: Capacitance Extraction via Image Mapping. Official implementation, 2026. https://github.com/THU-numbda/flash-cnncap

[3] C.-Y. Tsai, S. Kim and S.-K. Lim. Capacitance Extraction via Machine Learning with Application to Interconnect Geometry Exploration. ICCAD 2025. doi:10.1109/ICCAD66269.2025.11240935.

[4] J.-C. Tsai et al. ResCap: Fast-yet-Accurate Capacitance Extraction for Standard Cell Design by Physics-Guided Machine Learning. ASP-DAC 2025. doi:10.1145/3658617.3697737.

[5] M. S. Abouelyazid, S. Hammouda and Y. Ismail. Accuracy-Based Hybrid Parasitic Capacitance Extraction Using Rule-Based, Neural-Networks, and Field-Solver Methods. IEEE TCAD 41(12), 5681–5694, 2022. doi:10.1109/TCAD.2022.3161199. Author institutional abstract: https://fount.aucegypt.edu/faculty_journal_articles/4632/

[6] M. Garnelo et al. Conditional Neural Processes. ICML 2018. https://proceedings.mlr.press/v80/garnelo18a.html

[7] H. Kim et al. Attentive Neural Processes. ICLR 2019 / arXiv:1901.05761. https://arxiv.org/abs/1901.05761

[8] AIL-DNN: Modeling of IC Interconnect Parasitic Capacitances Based on Adaptive Incremental Learning. IEEE TCAD, 2025. doi:10.1109/TCAD.2025.3562947.
